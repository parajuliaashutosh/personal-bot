from pathlib import Path
from app.memory.vector import VectorStore

store = VectorStore()
texts = []

for file in Path("data/personal").glob("*"):
    texts.append(file.read_text())

store.add(texts)
print("Personal data ingested")
