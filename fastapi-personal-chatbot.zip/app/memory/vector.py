import chromadb
from sentence_transformers import SentenceTransformer

class VectorStore:
    def __init__(self):
        self.client = chromadb.Client()
        self.collection = self.client.get_or_create_collection("memory")
        self.embedder = SentenceTransformer("all-MiniLM-L6-v2")

    def add(self, texts):
        embeddings = self.embedder.encode(texts).tolist()
        ids = [str(i) for i in range(len(texts))]
        self.collection.add(documents=texts, embeddings=embeddings, ids=ids)

    def search(self, query, k=5):
        embedding = self.embedder.encode([query]).tolist()
        result = self.collection.query(query_embeddings=embedding, n_results=k)
        return "\n".join(result["documents"][0])
